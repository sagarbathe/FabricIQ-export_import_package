"""Fabric Ontology Export — export ontology definitions to a lakehouse folder."""

from ._core import export_ontology

__all__ = ["export_ontology"]
__version__ = "1.1.0"
